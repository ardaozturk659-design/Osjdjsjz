package com.multiverse;

import net.minecraft.init.Biomes;
import net.minecraft.world.DimensionType;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.biome.BiomeProviderSingle;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraftforge.common.DimensionManager;

public class MultiverseProvider extends WorldProvider {
    @Override
    protected void init() {
        super.init();
        this.biomeProvider = new BiomeProviderSingle(Biomes.PLAINS);
        if (world.isRemote) {
            ClientHooks.setup(this);
        }
    }

    @Override
    public DimensionType getDimensionType() {
        return DimensionManager.getProviderType(getDimension());
    }

    @Override
    public IChunkGenerator createChunkGenerator() {
        return new MultiverseGenerator(world, Themes.byDimension(getDimension()));
    }
}
