package com.multiverse;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ITeleporter;

public class MvTeleporter implements ITeleporter {
    public static BlockPos spawnFor(World w) {
        int dim = w.provider.getDimension();
        if (dim == 0) {
            return w.getTopSolidOrLiquidBlock(w.getSpawnPoint());
        }
        Theme t = Themes.byDimension(dim);
        int z = (t != null && t.castle) ? -75 : 0;
        return w.getTopSolidOrLiquidBlock(new BlockPos(0, 0, z));
    }

    @Override
    public void placeEntity(World world, Entity entity, float yaw) {
        BlockPos p = spawnFor(world);
        entity.motionX = 0;
        entity.motionY = 0;
        entity.motionZ = 0;
        entity.setLocationAndAngles(p.getX() + 0.5, p.getY(), p.getZ() + 0.5, yaw, entity.rotationPitch);
    }
}
