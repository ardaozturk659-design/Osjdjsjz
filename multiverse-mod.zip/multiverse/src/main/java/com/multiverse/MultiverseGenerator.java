package com.multiverse;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Biomes;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.NoiseGeneratorPerlin;

public class MultiverseGenerator implements IChunkGenerator {
    private static final IBlockState STONE = Blocks.STONE.getDefaultState();
    private static final IBlockState BEDROCK = Blocks.BEDROCK.getDefaultState();

    private final World world;
    private final Theme theme;
    private final NoiseGeneratorPerlin noise;

    public MultiverseGenerator(World world, Theme theme) {
        this.world = world;
        this.theme = theme;
        this.noise = new NoiseGeneratorPerlin(new Random(world.getSeed() + theme.index * 31L), 4);
    }

    private int height(int wx, int wz) {
        double n = noise.getValue(wx * 0.01D, wz * 0.01D);
        double h = theme.base + n * 6.0D;
        if (theme.castle) {
            int d = Math.max(Math.abs(wx), Math.abs(wz));
            if (d <= 64) return 63;
            if (d < 104) {
                double t = (d - 64) / 40.0D;
                h = 63 + (h - 63) * t;
            }
        }
        return (int) Math.max(40, Math.min(110, h));
    }

    @Override
    public Chunk generateChunk(int cx, int cz) {
        ChunkPrimer p = new ChunkPrimer();
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int wx = cx * 16 + lx, wz = cz * 16 + lz;
                int h = height(wx, wz);
                p.setBlockState(lx, 0, lz, BEDROCK);
                for (int y = 1; y <= h; y++) {
                    IBlockState s = (y == h) ? theme.top : (y >= h - 3 ? theme.filler : STONE);
                    p.setBlockState(lx, y, lz, s);
                }
                if (theme.liquid != null) {
                    for (int y = h + 1; y <= 62; y++) p.setBlockState(lx, y, lz, theme.liquid);
                }
                if (theme.castle && Math.abs(wx) <= 56 && Math.abs(wz) <= 56) {
                    for (int y = 63; y <= 170; y++) {
                        IBlockState s = Castle.block(wx, y, wz);
                        if (s != null) p.setBlockState(lx, y, lz, s);
                    }
                }
            }
        }
        Chunk chunk = new Chunk(world, p, cx, cz);
        byte[] biomes = chunk.getBiomeArray();
        Arrays.fill(biomes, (byte) Biome.getIdForBiome(Biomes.PLAINS));
        chunk.generateSkylightMap();
        return chunk;
    }

    @Override
    public void populate(int x, int z) {
    }

    @Override
    public boolean generateStructures(Chunk chunkIn, int x, int z) {
        return false;
    }

    @Override
    public List<Biome.SpawnListEntry> getPossibleCreatures(EnumCreatureType type, BlockPos pos) {
        return Biomes.PLAINS.getSpawnableList(type);
    }

    @Nullable
    @Override
    public BlockPos getNearestStructurePos(World worldIn, String name, BlockPos pos, boolean findUnexplored) {
        return null;
    }

    @Override
    public void recreateStructures(Chunk chunkIn, int x, int z) {
    }

    public boolean isInsideStructure(World worldIn, String name, BlockPos pos) {
        return false;
    }
}
