package com.multiverse;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

@Mod(modid = "multiverse", name = "Multiverse", version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class Multiverse {
    @SidedProxy(clientSide = "com.multiverse.ClientProxy", serverSide = "com.multiverse.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        Dimensions.register();
        proxy.preInit(e);
    }

    @Mod.EventHandler
    public void serverStart(FMLServerStartingEvent e) {
        e.registerServerCommand(new CommandMv());
    }
}
