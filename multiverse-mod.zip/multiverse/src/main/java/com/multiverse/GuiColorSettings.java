package com.multiverse;

import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.input.Keyboard;

public class GuiColorSettings extends GuiScreen {
    private static final String[] NAMES = {"Çimen rengi", "Yıldırım rengi", "Gökyüzü rengi"};
    private int sel = 0, drag = 0;
    private float hue = 0, sat = 1, val = 1;
    private int px, py, pw, ph, hx;
    private GuiTextField hex;
    private boolean pendingGrass = false;

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        buttonList.clear();
        int bw = Math.min(110, (width - 20) / 3);
        int sx = (width - (bw * 3 + 8)) / 2;
        for (int i = 0; i < 3; i++) {
            buttonList.add(new GuiButton(i, sx + i * (bw + 4), 8, bw, 20, NAMES[i]));
        }
        pw = Math.max(80, Math.min(180, width - 80));
        ph = Math.max(60, Math.min(120, height - 150));
        px = (width - (pw + 8 + 14)) / 2;
        py = 58;
        hx = px + pw + 8;
        hex = new GuiTextField(100, fontRenderer, px, py + ph + 10, 70, 18);
        hex.setMaxStringLength(7);
        int by = py + ph + 36;
        buttonList.add(new GuiButton(10, px, by, 80, 20, "Sıfırla"));
        buttonList.add(new GuiButton(11, px + 84, by, 100, 20, "Kaydet ve kapat"));
        loadSelected();
    }

    private int cur() {
        return sel == 0 ? ColorSettings.grass : (sel == 1 ? ColorSettings.lightning : ColorSettings.sky);
    }

    private boolean enabled() {
        return sel == 0 ? ColorSettings.customGrass : (sel == 1 ? ColorSettings.customLightning : ColorSettings.customSky);
    }

    private void put(int c) {
        c &= 0xFFFFFF;
        if (sel == 0) {
            ColorSettings.grass = c;
            ColorSettings.customGrass = true;
            pendingGrass = true;
        } else if (sel == 1) {
            ColorSettings.lightning = c;
            ColorSettings.customLightning = true;
        } else {
            ColorSettings.sky = c;
            ColorSettings.customSky = true;
        }
    }

    private void loadSelected() {
        int c = cur();
        float[] h = rgb2hsv(c);
        hue = h[0];
        sat = h[1];
        val = h[2];
        hex.setText(String.format("#%06X", c));
    }

    private void applyFromHsv() {
        int c = hsv(hue, sat, val);
        put(c);
        hex.setText(String.format("#%06X", c));
    }

    private void refresh() {
        if (pendingGrass) {
            pendingGrass = false;
            mc.renderGlobal.loadRenderers();
        }
    }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        if (b.id >= 0 && b.id <= 2) {
            sel = b.id;
            loadSelected();
        } else if (b.id == 10) {
            if (sel == 0) {
                ColorSettings.customGrass = false;
                pendingGrass = true;
            } else if (sel == 1) {
                ColorSettings.customLightning = false;
            } else {
                ColorSettings.customSky = false;
            }
            ColorSettings.save();
            refresh();
        } else if (b.id == 11) {
            mc.displayGuiScreen(null);
        }
    }

    @Override
    public void updateScreen() {
        hex.updateCursorCounter();
    }

    @Override
    protected void keyTyped(char c, int code) throws IOException {
        if (hex.isFocused() && code != Keyboard.KEY_ESCAPE) {
            hex.textboxKeyTyped(c, code);
            String s = hex.getText().replace("#", "");
            if (s.length() == 6) {
                try {
                    int rgb = Integer.parseInt(s, 16);
                    put(rgb);
                    float[] h = rgb2hsv(rgb);
                    hue = h[0];
                    sat = h[1];
                    val = h[2];
                    refresh();
                } catch (NumberFormatException ignored) {
                }
            }
        } else {
            super.keyTyped(c, code);
        }
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);
        hex.mouseClicked(mx, my, btn);
        if (btn == 0) {
            if (mx >= px && mx <= px + pw && my >= py && my <= py + ph) drag = 1;
            else if (mx >= hx && mx <= hx + 14 && my >= py && my <= py + ph) drag = 2;
            if (drag != 0) handleDrag(mx, my);
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long time) {
        if (drag != 0) handleDrag(mx, my);
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        super.mouseReleased(mx, my, state);
        if (drag != 0) {
            drag = 0;
            refresh();
        }
    }

    private void handleDrag(int mx, int my) {
        if (drag == 1) {
            sat = clamp((mx - px) / (float) pw);
            val = 1f - clamp((my - py) / (float) ph);
        } else {
            hue = clamp((my - py) / (float) ph);
        }
        applyFromHsv();
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
        ColorSettings.save();
        refresh();
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        drawCenteredString(fontRenderer, "Multiverse - " + NAMES[sel], width / 2, 36, 0xFFFFFF);
        drawSV(px, py, pw, ph, hsv(hue, 1f, 1f));
        drawHue(hx, py, 14, ph);
        int cx = px + (int) (sat * pw), cy = py + (int) ((1f - val) * ph);
        drawRect(cx - 3, cy - 3, cx + 4, cy + 4, 0xFFFFFFFF);
        drawRect(cx - 2, cy - 2, cx + 3, cy + 3, 0xFF000000 | cur());
        int hy = py + (int) (hue * ph);
        drawRect(hx - 2, hy - 1, hx + 16, hy + 2, 0xFFFFFFFF);
        drawRect(px + 76, py + ph + 10, px + 94, py + ph + 28, 0xFF000000 | cur());
        drawString(fontRenderer, enabled() ? "Özel renk açık" : "Varsayılan renk", px + 100, py + ph + 15, 0xAAAAAA);
        hex.drawTextBox();
        super.drawScreen(mx, my, pt);
    }

    private void drawSV(int x, int y, int w, int h, int hueRgb) {
        int hr = (hueRgb >> 16) & 255, hg = (hueRgb >> 8) & 255, hb = hueRgb & 255;
        GlStateManager.disableTexture2D();
        GlStateManager.disableAlpha();
        GlStateManager.shadeModel(7425);
        Tessellator t = Tessellator.getInstance();
        BufferBuilder b = t.getBuffer();
        b.begin(7, DefaultVertexFormats.POSITION_COLOR);
        b.pos(x, y + h, 0).color(0, 0, 0, 255).endVertex();
        b.pos(x + w, y + h, 0).color(0, 0, 0, 255).endVertex();
        b.pos(x + w, y, 0).color(hr, hg, hb, 255).endVertex();
        b.pos(x, y, 0).color(255, 255, 255, 255).endVertex();
        t.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    private void drawHue(int x, int y, int w, int h) {
        GlStateManager.disableTexture2D();
        GlStateManager.disableAlpha();
        GlStateManager.shadeModel(7425);
        Tessellator t = Tessellator.getInstance();
        BufferBuilder b = t.getBuffer();
        b.begin(7, DefaultVertexFormats.POSITION_COLOR);
        for (int i = 0; i < 6; i++) {
            int c1 = hsv(i / 6f, 1f, 1f), c2 = hsv((i + 1) / 6f, 1f, 1f);
            int y1 = y + h * i / 6, y2 = y + h * (i + 1) / 6;
            b.pos(x, y2, 0).color((c2 >> 16) & 255, (c2 >> 8) & 255, c2 & 255, 255).endVertex();
            b.pos(x + w, y2, 0).color((c2 >> 16) & 255, (c2 >> 8) & 255, c2 & 255, 255).endVertex();
            b.pos(x + w, y1, 0).color((c1 >> 16) & 255, (c1 >> 8) & 255, c1 & 255, 255).endVertex();
            b.pos(x, y1, 0).color((c1 >> 16) & 255, (c1 >> 8) & 255, c1 & 255, 255).endVertex();
        }
        t.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    private static float clamp(float f) {
        return f < 0f ? 0f : (f > 1f ? 1f : f);
    }

    static int hsv(float h, float s, float v) {
        h = (h - (float) Math.floor(h)) * 6f;
        int i = (int) h;
        float f = h - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        float r, g, b;
        switch (i % 6) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return ((int) (r * 255 + 0.5f) << 16) | ((int) (g * 255 + 0.5f) << 8) | (int) (b * 255 + 0.5f);
    }

    static float[] rgb2hsv(int c) {
        float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        float d = max - min, h = 0f;
        if (d > 0f) {
            if (max == r) h = ((g - b) / d) % 6f;
            else if (max == g) h = (b - r) / d + 2f;
            else h = (r - g) / d + 4f;
            h /= 6f;
            if (h < 0f) h += 1f;
        }
        return new float[]{h, max == 0f ? 0f : d / max, max};
    }
}
