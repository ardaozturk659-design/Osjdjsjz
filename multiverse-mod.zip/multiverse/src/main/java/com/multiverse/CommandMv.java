package com.multiverse;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;

public class CommandMv extends CommandBase {
    @Override
    public String getName() {
        return "mv";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/mv <0-84 | ana | liste>";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 0;
    }

    @Override
    public boolean checkPermission(MinecraftServer server, ICommandSender sender) {
        return true;
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        EntityPlayerMP player = getCommandSenderAsPlayer(sender);
        if (args.length == 0 || args[0].equalsIgnoreCase("liste")) {
            int per = 17;
            int pages = (Themes.COUNT + per - 1) / per;
            int page = args.length > 1 ? parseInt(args[1], 1, pages) : 1;
            StringBuilder sb = new StringBuilder("/mv <0-" + (Themes.COUNT - 1) + ">  /mv ana  /mv liste <1-" + pages + ">  (sayfa " + page + ")\n");
            int from = (page - 1) * per;
            int to = Math.min(Themes.COUNT, page * per);
            for (int i = from; i < to; i++) {
                sb.append(i).append(" = ").append(Themes.ALL[i].name);
                sb.append((i - from) % 2 == 1 ? "\n" : "   ");
            }
            sender.sendMessage(new TextComponentString(sb.toString()));
            return;
        }
        int dim;
        if (args[0].equalsIgnoreCase("ana")) {
            dim = 0;
        } else if (args[0].equalsIgnoreCase("dark")) {
            dim = Themes.BASE;
        } else {
            dim = Themes.BASE + parseInt(args[0], 0, Themes.COUNT - 1);
        }
        if (player.dimension == dim) {
            BlockPos p = MvTeleporter.spawnFor(player.world);
            player.setPositionAndUpdate(p.getX() + 0.5, p.getY(), p.getZ() + 0.5);
        } else {
            player.changeDimension(dim, new MvTeleporter());
        }
    }
}
