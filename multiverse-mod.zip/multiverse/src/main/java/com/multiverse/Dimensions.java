package com.multiverse;

import net.minecraft.world.DimensionType;
import net.minecraftforge.common.DimensionManager;

public class Dimensions {
    public static void register() {
        for (int i = 0; i < Themes.COUNT; i++) {
            int id = Themes.BASE + i;
            DimensionType type = DimensionType.register("multiverse_" + i, "_mv" + i, id, MultiverseProvider.class, false);
            DimensionManager.registerDimension(id, type);
        }
    }
}
