package com.multiverse;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

public class ColorSettings {
    public static boolean customGrass, customLightning, customSky;
    public static int grass = 0x4CAF50, lightning = 0x737380, sky = 0x78A7FF;
    private static File file;

    public static void load(File configDir) {
        file = new File(configDir, "multiverse_colors.properties");
        if (!file.exists()) return;
        try (FileInputStream in = new FileInputStream(file)) {
            Properties p = new Properties();
            p.load(in);
            customGrass = Boolean.parseBoolean(p.getProperty("customGrass", "false"));
            customLightning = Boolean.parseBoolean(p.getProperty("customLightning", "false"));
            customSky = Boolean.parseBoolean(p.getProperty("customSky", "false"));
            grass = Integer.parseInt(p.getProperty("grass", "4CAF50"), 16);
            lightning = Integer.parseInt(p.getProperty("lightning", "737380"), 16);
            sky = Integer.parseInt(p.getProperty("sky", "78A7FF"), 16);
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        if (file == null) return;
        try (FileOutputStream out = new FileOutputStream(file)) {
            Properties p = new Properties();
            p.setProperty("customGrass", String.valueOf(customGrass));
            p.setProperty("customLightning", String.valueOf(customLightning));
            p.setProperty("customSky", String.valueOf(customSky));
            p.setProperty("grass", String.format("%06X", grass));
            p.setProperty("lightning", String.format("%06X", lightning));
            p.setProperty("sky", String.format("%06X", sky));
            p.store(out, "Multiverse renk ayarlari");
        } catch (Exception ignored) {
        }
    }
}
